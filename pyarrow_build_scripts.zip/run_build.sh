
sudo apt-get install libjemalloc-dev libboost-dev \
                       libboost-filesystem-dev \
                       libboost-system-dev \
                       libboost-regex-dev \
                       python3-dev \
                       autoconf \
                       flex \
                       bison \
                       libssl-dev \
                       curl \
                       cmake \
		       libatlas-base-dev \
		       libboost-atomic-dev \
		       clang-7 \
                       llvm-7-dev

source pyArrowVenv/bin/activate
which python
cd arrow/cpp
mkdir release
cd release/
unset ARROW_HOME
unset LD_LIBRARY_PATH
export ARROW_HOME=$(pwd)/release
export LD_LIBRARY_PATH=$(pwd)/release:$LD_LIBRARY_PATH

# ORC AND FLIGHT NOT SUPPORTED ON ARM_V7 as of version 1.0.0
# NOTE:- For armv7 or if error messages about undefined referenced about atomic libraries add -DARROW_CXXFLAGS=-latomic \
cmake -DCMAKE_INSTALL_PREFIX=$ARROW_HOME \
      -DCMAKE_INSTALL_LIBDIR=lib \
      -DARROW_PYTHON=ON \
      -DARROW_WITH_BZ2=ON \
      -DARROW_WITH_ZLIB=ON \
      -DARROW_WITH_ZSTD=ON \
      -DARROW_WITH_LZ4=ON \
      -DARROW_WITH_SNAPPY=ON \
      -DARROW_WITH_BROTLI=ON \
      -DARROW_WITH_PARQUET=ON \
      -DARROW_BUILD_TESTS=ON \
      -DARROW_PARQUET=ON \
      -DARROW_ORC=OFF \
      -DARROW_FLIGHT=OFF \
      -DPYTHON_EXECUTABLE=/usr/local/arrow_build/pyArrowVenv/bin/python3  \
      ..

make --jobs=`nproc`
make install
# Env Vars might have to be respecified for building wheel
