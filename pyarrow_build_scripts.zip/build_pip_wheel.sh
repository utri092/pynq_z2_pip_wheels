source pyArrowVenv/bin/activate
cd arrow/cpp
cd release/
unset ARROW_HOME
unset LD_LIBRARY_PATH
export ARROW_HOME=$(pwd)/release
export LD_LIBRARY_PATH=$(pwd)/release:$LD_LIBRARY_PATH
cd ../../python
/usr/local/arrow_build/pyArrowVenv/bin/python3 setup.py bdist_wheel
cd dist/
ls

