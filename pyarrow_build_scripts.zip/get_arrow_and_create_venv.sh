rm -rf pyArrowVenv
python3 -m venv pyArrowVenv
source pyArrowVenv/bin/activate
rm -rf arrow/
git clone https://github.com/apache/arrow
# Build problems arise on ARM architectures for versions less than  0.17.0
cd arrow/
git checkout -b apache-arrow-0.17.0 tags/apache-arrow-0.17.0
which pip
cd python/
pip install -r requirements-build.txt
pip install -r requirements-test.txt
pip install wheel
